<?php
$this->breadcrumbs=array(
	'Atividades'=>array('index'),
	$model->nome_atividade,
);

$this->menu=array(
	array('label'=>'Listar Atividades', 'url'=>array('index')),
	array('label'=>'Adicionar Atividade', 'url'=>array('create')),
	array('label'=>'Editar Atividade', 'url'=>array('update', 'id'=>$model->cod_atividade)),
	array('label'=>'Deletar Atividade', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->cod_atividade),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Gerenciar Atividades', 'url'=>array('admin')),
);
?>

<?php $url = $this->createUrl('/atividade/createPasso', array('id'=>$model->cod_atividade))?>
<?php Yii::app()->clientScript->registerScript('addPasso', "
	$('#addPasso').click(
	function(){
		if(($('#AtividadePasso_cod_pessoa').val()) && ($('#AtividadePasso_descricao').val())){
		$.post('{$url}', 
		$('#passo-form').serialize()
		,
   		function(data) {
     		$('#passos-holder').append(data + '<br>');
     		//$('.ok-button').click(okButtonListener);
	   	});
	   	}else{
	   		alert('Você deve preencher a descrição e responsável');
	   	}
	}
	
	);
");?>

<?php $url = $this->createUrl('/atividade/passoConcluido')?>
<?php Yii::app()->clientScript->registerScript('okPasso', "
	function okButtonListener(){
		if(this.checked){
			
			$(this).parent('div').hide('slow');
			
			$.post('{$url}' + '/' + $(this).attr('id') , 
				{finalizado: true, 
				},
		
   		function(data) {
     		$('#passos-holder').append(data);
	   	});
		}else{
			
			$(this).parent('div').hide('slow');
		
			$.post('{$url}' + '/' + $(this).attr('id') ,
				{finalizado: false},
		
   		function(data) {
     		$('#passos-holder').append(data);
	   	});
	}
		$('.ok-button').unbind('click');
		$('.ok-button').click(okButtonListener);
	}
	
	$('.ok-button').click(okButtonListener);
");?>

<div class="view <?php echo $model->class;?>">
<h4 align="center"><b><?php echo $model->nome_atividade; ?></b></h4>
	
	<b>Categoria:</b>
	<?php if(is_object($model->categoria)):?>
	<?php if($model->categoria->categoriaPai->cod_categoria != $model->categoria->cod_categoria ):?>
		<?php echo CHtml::encode($model->categoria->categoriaPai->nome);?> <b>&gt;</b> 
	<?php endif;?>
	 <?php echo CHtml::encode($model->categoria->nome);?>
	<?php endif;?>
		
	<br />
	
	<b><?php echo CHtml::encode($model->getAttributeLabel('responsavel')); ?>:</b>
	<?php echo CHtml::encode($model->responsavel->nome); ?>
	<br />

	<b><?php echo CHtml::encode($model->getAttributeLabel('tipo_vinculo')); ?>:</b>
	<?php echo CHtml::encode($model->tipo_vinculo); ?>
	<br />

	<b><?php echo CHtml::encode($model->getAttributeLabel('data_inicio')); ?>:</b>
	<?php echo CHtml::encode($model->data_inicio); ?>
	<br />

	<b><?php echo CHtml::encode($model->getAttributeLabel('data_fim')); ?>:</b>
	<?php echo CHtml::encode($model->data_fim); ?>
	<br />
	
	<b><?php echo CHtml::encode($model->getAttributeLabel('data_criacao')); ?>:</b>
	<?php echo CHtml::encode($model->data_criacao); ?>
	<br />
	
	<b><?php echo CHtml::encode($model->getAttributeLabel('data_edicao')); ?>:</b>
	<?php echo CHtml::encode($model->data_edicao); ?>
	<br />

	<b><?php echo CHtml::encode($model->getAttributeLabel('turnos_trabalho')); ?>:</b>
	<?php echo CHtml::encode($model->turnos_trabalho); ?>
	<br />
	
	<b><?php echo CHtml::encode($model->getAttributeLabel('status')); ?>:</b>
	<?php echo CHtml::encode($model->status); ?>
	<br />

</div>
	
<div class="info">
	<?php echo $model->descricao; ?>
</div>

<div class="view" id="passos-holder">
	<h4>Passos</h4>
	<?php foreach($model->passos as $p):?>
		<?php $this->renderPartial('/atividade/passo/_view', array('model'=>$p))?>
	<?php endforeach;?>
	<br>
</div>

<div class="view form">
<h2>Adicionar Passo</h2>
<?php $passo = new AtividadePasso();?>
<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'passo-form',
	'enableAjaxValidation'=>true,
	'enableClientValidation'=>true,
)); ?>

	<?php echo $form->errorSummary($passo); ?>
	
	<div class="row">
		<?php echo $form->labelEx($passo,'descricao'); ?>
		<?php echo $form->textField($passo,'descricao', array('size'=>'65', 'placeholder'=>"Descrição")); ?>
		<?php echo $form->error($passo,'descricao'); ?>
	</div>
	
	<div class="row">
		<?php echo $form->labelEx($passo,'cod_pessoa'); ?>
		<?php $listDataPessoas = CHtml::listData(Pessoa::model()->with('categoria')->findAll(array('order'=>'equipe_atual DESC, t.nome')), 'cod_pessoa', 'nome', 'categoria.nome');?>
		<?php  echo $form->dropDownList($passo,'cod_pessoa', $listDataPessoas, array('prompt'=>"Selecione uma Pessoa")); ?>
		<?php echo $form->error($passo,'cod_pessoa'); ?>
	</div>	
	

	<div class="row buttons">
        <?php echo CHtml::link('Adicionar',null, array("id"=>'addPasso', 'class'=>'button'))?>
	</div>

<?php $this->endWidget(); ?>    
</div>    
    
<div class="view">
	<label><b>Participantes</b></label><br>
	<?php foreach($model->pessoas as $pessoa):?>
		<?php echo CHtml::encode($pessoa->nome); ?>
		<br />
	<?php endforeach;?>
</div>

<div class="view">
	<label><b>Projetos</b></label><br>
	<?php foreach($model->projetos as $projeto):?>
		<?php echo CHtml::encode($projeto->nome); ?>
		<br />
	<?php endforeach;?>
</div>

<div class="view">
	<label><b>Bolsas</b></label><br>
	<?php foreach($model->bolsas as $bolsa):?>
		<?php echo CHtml::encode($bolsa->categoria .' (' .$bolsa->pessoa->nome .')'); ?>
		<br />
	<?php endforeach;?>
</div>



