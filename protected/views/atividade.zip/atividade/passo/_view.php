<div class="passo <?php echo $model->finalizado ? "verde" : "amarelo"?>" style="padding: 5px;">
<b>Finalizado:</b> <?php echo CHtml::checkBox('',$model->finalizado ,array('id'=>$model->cod_passo, 'class'=>'ok-button'))?><br/>
<b><?php echo CHtml::encode($model->getAttributeLabel('descricao')); ?>:</b>
<?php echo CHtml::encode($model->descricao); ?>
<br />
<b>Responsavel:</b>
<?php echo CHtml::encode($model->pessoa->nome_curto); ?>
<br />
<b>Data de Criacao:</b>
<?php echo CHtml::encode($model->data_criacao); ?>
<br />
<?php if($model->finalizado):?>
	<b>Data de Conclusao:</b>
	<?php echo CHtml::encode($model->data_finalizacao); ?>
	<br />
<?php endif;?>
</div>
<br>
